<?php
// created: 2018-06-01 20:39:05
$dictionary["CAT_Catalogo_Documentos"]["fields"]["cm_catalogodependencias_cat_catalogo_documentos"] = array (
  'name' => 'cm_catalogodependencias_cat_catalogo_documentos',
  'type' => 'link',
  'relationship' => 'cm_catalogodependencias_cat_catalogo_documentos',
  'source' => 'non-db',
  'module' => 'CM_CatalogoDependencias',
  'bean_name' => 'CM_CatalogoDependencias',
  'vname' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'id_name' => 'cm_catalogf37cdencias_ida',
);
