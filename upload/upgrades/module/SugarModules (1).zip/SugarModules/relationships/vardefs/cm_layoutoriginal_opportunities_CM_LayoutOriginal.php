<?php
// created: 2018-06-01 20:38:54
$dictionary["CM_LayoutOriginal"]["fields"]["cm_layoutoriginal_opportunities"] = array (
  'name' => 'cm_layoutoriginal_opportunities',
  'type' => 'link',
  'relationship' => 'cm_layoutoriginal_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_CM_LAYOUTORIGINAL_TITLE',
  'id_name' => 'cm_layoutoriginal_opportunitiescm_layoutoriginal_ida',
  'link-type' => 'many',
  'side' => 'left',
);
