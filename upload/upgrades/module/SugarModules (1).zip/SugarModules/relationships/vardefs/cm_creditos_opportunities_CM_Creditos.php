<?php
// created: 2018-06-01 20:38:59
$dictionary["CM_Creditos"]["fields"]["cm_creditos_opportunities"] = array (
  'name' => 'cm_creditos_opportunities',
  'type' => 'link',
  'relationship' => 'cm_creditos_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_CM_CREDITOS_TITLE',
  'id_name' => 'cm_creditos_opportunitiescm_creditos_ida',
  'link-type' => 'many',
  'side' => 'left',
);
