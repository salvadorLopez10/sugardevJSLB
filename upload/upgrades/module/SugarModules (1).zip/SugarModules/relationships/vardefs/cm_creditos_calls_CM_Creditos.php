<?php
// created: 2018-06-01 20:38:59
$dictionary["CM_Creditos"]["fields"]["cm_creditos_calls"] = array (
  'name' => 'cm_creditos_calls',
  'type' => 'link',
  'relationship' => 'cm_creditos_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_CM_CREDITOS_CALLS_FROM_CM_CREDITOS_TITLE',
  'id_name' => 'cm_creditos_callscm_creditos_ida',
  'link-type' => 'many',
  'side' => 'left',
);
