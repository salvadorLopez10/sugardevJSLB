<?php
// created: 2018-06-01 20:38:54
$dictionary["CM_LayoutOriginal"]["fields"]["cm_layoutoriginal_cm_creditos"] = array (
  'name' => 'cm_layoutoriginal_cm_creditos',
  'type' => 'link',
  'relationship' => 'cm_layoutoriginal_cm_creditos',
  'source' => 'non-db',
  'module' => 'CM_Creditos',
  'bean_name' => 'CM_Creditos',
  'vname' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_LAYOUTORIGINAL_TITLE',
  'id_name' => 'cm_layoutoriginal_cm_creditoscm_layoutoriginal_ida',
  'link-type' => 'many',
  'side' => 'left',
);
