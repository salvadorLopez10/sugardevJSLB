<?php
// created: 2018-06-01 20:38:54
$dictionary["CM_LayoutOriginal"]["fields"]["cm_layoutoriginal_accounts"] = array (
  'name' => 'cm_layoutoriginal_accounts',
  'type' => 'link',
  'relationship' => 'cm_layoutoriginal_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_CM_LAYOUTORIGINAL_TITLE',
  'id_name' => 'cm_layoutoriginal_accountscm_layoutoriginal_ida',
  'link-type' => 'many',
  'side' => 'left',
);
