<?php
// created: 2018-06-01 20:39:05
$dictionary["CM_CatalogoDependencias"]["fields"]["cm_catalogodependencias_cat_catalogo_documentos"] = array (
  'name' => 'cm_catalogodependencias_cat_catalogo_documentos',
  'type' => 'link',
  'relationship' => 'cm_catalogodependencias_cat_catalogo_documentos',
  'source' => 'non-db',
  'module' => 'CAT_Catalogo_Documentos',
  'bean_name' => 'CAT_Catalogo_Documentos',
  'vname' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'id_name' => 'cm_catalog0787umentos_idb',
);
