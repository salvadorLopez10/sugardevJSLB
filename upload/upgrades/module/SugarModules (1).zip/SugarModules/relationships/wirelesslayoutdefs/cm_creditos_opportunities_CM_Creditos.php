<?php
 // created: 2018-06-01 20:39:02
$layout_defs["CM_Creditos"]["subpanel_setup"]['cm_creditos_opportunities'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'cm_creditos_opportunities',
);
