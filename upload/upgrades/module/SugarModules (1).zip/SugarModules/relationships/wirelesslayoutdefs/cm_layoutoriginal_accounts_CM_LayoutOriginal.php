<?php
 // created: 2018-06-01 20:38:56
$layout_defs["CM_LayoutOriginal"]["subpanel_setup"]['cm_layoutoriginal_accounts'] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'cm_layoutoriginal_accounts',
);
