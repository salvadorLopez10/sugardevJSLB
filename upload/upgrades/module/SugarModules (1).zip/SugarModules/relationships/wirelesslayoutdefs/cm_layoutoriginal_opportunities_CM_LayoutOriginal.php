<?php
 // created: 2018-06-01 20:38:56
$layout_defs["CM_LayoutOriginal"]["subpanel_setup"]['cm_layoutoriginal_opportunities'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'cm_layoutoriginal_opportunities',
);
