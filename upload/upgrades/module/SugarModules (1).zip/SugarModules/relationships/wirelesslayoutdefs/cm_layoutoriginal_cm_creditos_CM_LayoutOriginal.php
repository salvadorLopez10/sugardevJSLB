<?php
 // created: 2018-06-01 20:38:56
$layout_defs["CM_LayoutOriginal"]["subpanel_setup"]['cm_layoutoriginal_cm_creditos'] = array (
  'order' => 100,
  'module' => 'CM_Creditos',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'get_subpanel_data' => 'cm_layoutoriginal_cm_creditos',
);
