<?php
 // created: 2018-06-01 20:39:02
$layout_defs["CM_Creditos"]["subpanel_setup"]['cm_creditos_calls'] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'cm_creditos_calls',
);
