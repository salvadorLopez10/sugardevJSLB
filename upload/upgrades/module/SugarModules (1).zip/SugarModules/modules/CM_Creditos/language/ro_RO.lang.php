<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Echipe',
  'LBL_TEAMS' => 'Echipe',
  'LBL_TEAM_ID' => 'Id Echipă',
  'LBL_ASSIGNED_TO_ID' => 'Atribuit ID Utilizator',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuit lui',
  'LBL_TAGS_LINK' => 'Etichete',
  'LBL_TAGS' => 'Etichete',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data creării',
  'LBL_DATE_MODIFIED' => 'Data Modificarii',
  'LBL_MODIFIED' => 'Modificat de',
  'LBL_MODIFIED_ID' => 'Modificat după Id',
  'LBL_MODIFIED_NAME' => 'Modificat după Nume',
  'LBL_CREATED' => 'Creat de',
  'LBL_CREATED_ID' => 'Creat de Id',
  'LBL_DOC_OWNER' => 'Proprietar document',
  'LBL_USER_FAVORITES' => 'Utilizatori cu setări favorite',
  'LBL_DESCRIPTION' => 'Descriere',
  'LBL_DELETED' => 'Şters',
  'LBL_NAME' => 'Nume',
  'LBL_CREATED_USER' => 'Creat de Utilizator',
  'LBL_MODIFIED_USER' => 'Modificat după Utilizator',
  'LBL_LIST_NAME' => 'Nume',
  'LBL_EDIT_BUTTON' => 'Editeaza',
  'LBL_REMOVE' => 'Eliminare',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificat după Nume',
  'LBL_LIST_FORM_TITLE' => 'Créditos Lista',
  'LBL_MODULE_NAME' => 'Créditos',
  'LBL_MODULE_TITLE' => 'Créditos',
  'LBL_MODULE_NAME_SINGULAR' => 'Créditos',
  'LBL_HOMEPAGE_TITLE' => 'Al meu Créditos',
  'LNK_NEW_RECORD' => 'Creează Créditos',
  'LNK_LIST' => 'Vizualizare Créditos',
  'LNK_IMPORT_CM_CREDITOS' => 'Importar Créditos',
  'LBL_SEARCH_FORM_TITLE' => 'Cauta Créditos',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Vizualizare Istoric',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activitati',
  'LBL_CM_CREDITOS_SUBPANEL_TITLE' => 'Créditos',
  'LBL_NEW_FORM_TITLE' => 'Nou Créditos',
  'LNK_IMPORT_VCARD' => 'Importar Créditos vCard',
  'LBL_IMPORT' => 'Importar Créditos',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Créditos record by importing a vCard from your file system.',
  'LBL_TCT_ID_CREDITO_INT_C' => 'Id Crédito',
  'LBL_TCT_DAP_TXF_C' => 'Dap',
  'LBL_TCT_FECHA_DE_EMISION_DAT_C' => 'Fecha de Emisión',
  'LBL_CURRENCY' => 'Moneda',
  'LBL_TCT_IMPORTE_ORIGINAL_CUR_C' => 'Importe Original',
  'LBL_TCT_CAPITAL_ORIGINAL_CUR_C' => 'Capital Original',
  'LBL_TCT_PLAZO_ORIGINAL_INT_C' => 'Plazo Original',
  'LBL_TCT_ULTIMO_PAGO_DAT_C' => 'Último Pago',
  'LBL_TCT_SALDO_PROYECTADO_CUR_C' => 'Saldo Proyectado',
  'LBL_TCT_CAMPANA_TXF_C' => 'Campaña',
  'LBL_CAMPANIA_CARGA_SEGMENTO_TXF' => 'Campaña',
  'LBL_CAMPANIA_CARGA_SEGMENTO_TXF_C' => 'Campaña',
);