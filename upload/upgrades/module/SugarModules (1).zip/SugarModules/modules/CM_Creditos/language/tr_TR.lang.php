<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Takımlar',
  'LBL_TEAMS' => 'Takımlar',
  'LBL_TEAM_ID' => 'Takım ID',
  'LBL_ASSIGNED_TO_ID' => 'Atanan Kullanıcı ID',
  'LBL_ASSIGNED_TO_NAME' => 'Atanan Kişi',
  'LBL_TAGS_LINK' => 'Etiketler',
  'LBL_TAGS' => 'Etiketler',
  'LBL_ID' => 'KİMLİK',
  'LBL_DATE_ENTERED' => 'Oluşturulma Tarihi',
  'LBL_DATE_MODIFIED' => 'Değiştirilme Tarihi',
  'LBL_MODIFIED' => 'Değiştiren',
  'LBL_MODIFIED_ID' => 'Değiştiren ID',
  'LBL_MODIFIED_NAME' => 'Değiştiren Kişinin İsmi',
  'LBL_CREATED' => 'Oluşturan',
  'LBL_CREATED_ID' => 'Oluşturan ID',
  'LBL_DOC_OWNER' => 'Doküman Sahibi',
  'LBL_USER_FAVORITES' => 'Favori Olan Kullanıcılar',
  'LBL_DESCRIPTION' => 'Tanım',
  'LBL_DELETED' => 'Silindi',
  'LBL_NAME' => 'İsim',
  'LBL_CREATED_USER' => 'Oluşturan Kullanıcı',
  'LBL_MODIFIED_USER' => 'Değiştiren Kullanıcı',
  'LBL_LIST_NAME' => 'İsim',
  'LBL_EDIT_BUTTON' => 'Değiştir',
  'LBL_REMOVE' => 'Sil',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Değiştiren Kişinin İsmi',
  'LBL_LIST_FORM_TITLE' => 'Créditos Liste',
  'LBL_MODULE_NAME' => 'Créditos',
  'LBL_MODULE_TITLE' => 'Créditos',
  'LBL_MODULE_NAME_SINGULAR' => 'Créditos',
  'LBL_HOMEPAGE_TITLE' => 'Benim Créditos',
  'LNK_NEW_RECORD' => 'Oluştur Créditos',
  'LNK_LIST' => 'Göster Créditos',
  'LNK_IMPORT_CM_CREDITOS' => 'Importar Créditos',
  'LBL_SEARCH_FORM_TITLE' => 'Ara Créditos',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Tarihçeyi Gör',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteler',
  'LBL_CM_CREDITOS_SUBPANEL_TITLE' => 'Créditos',
  'LBL_NEW_FORM_TITLE' => 'Yeni Créditos',
  'LNK_IMPORT_VCARD' => 'Importar Créditos vCard',
  'LBL_IMPORT' => 'Importar Créditos',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Créditos record by importing a vCard from your file system.',
  'LBL_TCT_ID_CREDITO_INT_C' => 'Id Crédito',
  'LBL_TCT_DAP_TXF_C' => 'Dap',
  'LBL_TCT_FECHA_DE_EMISION_DAT_C' => 'Fecha de Emisión',
  'LBL_CURRENCY' => 'Moneda',
  'LBL_TCT_IMPORTE_ORIGINAL_CUR_C' => 'Importe Original',
  'LBL_TCT_CAPITAL_ORIGINAL_CUR_C' => 'Capital Original',
  'LBL_TCT_PLAZO_ORIGINAL_INT_C' => 'Plazo Original',
  'LBL_TCT_ULTIMO_PAGO_DAT_C' => 'Último Pago',
  'LBL_TCT_SALDO_PROYECTADO_CUR_C' => 'Saldo Proyectado',
  'LBL_TCT_CAMPANA_TXF_C' => 'Campaña',
  'LBL_CAMPANIA_CARGA_SEGMENTO_TXF' => 'Campaña',
  'LBL_CAMPANIA_CARGA_SEGMENTO_TXF_C' => 'Campaña',
);