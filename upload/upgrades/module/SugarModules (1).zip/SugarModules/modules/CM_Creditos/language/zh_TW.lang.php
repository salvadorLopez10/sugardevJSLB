<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => '小組',
  'LBL_TEAMS' => '小組',
  'LBL_TEAM_ID' => '小組 ID',
  'LBL_ASSIGNED_TO_ID' => '指派的使用者 ID',
  'LBL_ASSIGNED_TO_NAME' => '已指派至',
  'LBL_TAGS_LINK' => '標籤',
  'LBL_TAGS' => '標籤',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => '建立日期',
  'LBL_DATE_MODIFIED' => '修改日期',
  'LBL_MODIFIED' => '修改人',
  'LBL_MODIFIED_ID' => '按 ID 修改',
  'LBL_MODIFIED_NAME' => '按名稱修改',
  'LBL_CREATED' => '建立人',
  'LBL_CREATED_ID' => '按 ID 建立',
  'LBL_DOC_OWNER' => '文件擁有者',
  'LBL_USER_FAVORITES' => '最愛的使用者',
  'LBL_DESCRIPTION' => '描述',
  'LBL_DELETED' => '已刪除',
  'LBL_NAME' => '名稱',
  'LBL_CREATED_USER' => '由使用者建立',
  'LBL_MODIFIED_USER' => '由使用者修改',
  'LBL_LIST_NAME' => '名稱',
  'LBL_EDIT_BUTTON' => '編輯',
  'LBL_REMOVE' => '移除',
  'LBL_EXPORT_MODIFIED_BY_NAME' => '按名稱修改',
  'LBL_LIST_FORM_TITLE' => 'Créditos 清單',
  'LBL_MODULE_NAME' => 'Créditos',
  'LBL_MODULE_TITLE' => 'Créditos',
  'LBL_MODULE_NAME_SINGULAR' => 'Créditos',
  'LBL_HOMEPAGE_TITLE' => '我的 Créditos',
  'LNK_NEW_RECORD' => '建立 Créditos',
  'LNK_LIST' => '檢視 Créditos',
  'LNK_IMPORT_CM_CREDITOS' => 'Importar Créditos',
  'LBL_SEARCH_FORM_TITLE' => '搜尋 Créditos',
  'LBL_HISTORY_SUBPANEL_TITLE' => '檢視歷史',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => '活動流',
  'LBL_CM_CREDITOS_SUBPANEL_TITLE' => 'Créditos',
  'LBL_NEW_FORM_TITLE' => '新 Créditos',
  'LNK_IMPORT_VCARD' => 'Importar Créditos vCard',
  'LBL_IMPORT' => 'Importar Créditos',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Créditos record by importing a vCard from your file system.',
  'LBL_TCT_ID_CREDITO_INT_C' => 'Id Crédito',
  'LBL_TCT_DAP_TXF_C' => 'Dap',
  'LBL_TCT_FECHA_DE_EMISION_DAT_C' => 'Fecha de Emisión',
  'LBL_CURRENCY' => 'Moneda',
  'LBL_TCT_IMPORTE_ORIGINAL_CUR_C' => 'Importe Original',
  'LBL_TCT_CAPITAL_ORIGINAL_CUR_C' => 'Capital Original',
  'LBL_TCT_PLAZO_ORIGINAL_INT_C' => 'Plazo Original',
  'LBL_TCT_ULTIMO_PAGO_DAT_C' => 'Último Pago',
  'LBL_TCT_SALDO_PROYECTADO_CUR_C' => 'Saldo Proyectado',
  'LBL_TCT_CAMPANA_TXF_C' => 'Campaña',
  'LBL_CAMPANIA_CARGA_SEGMENTO_TXF' => 'Campaña',
  'LBL_CAMPANIA_CARGA_SEGMENTO_TXF_C' => 'Campaña',
);