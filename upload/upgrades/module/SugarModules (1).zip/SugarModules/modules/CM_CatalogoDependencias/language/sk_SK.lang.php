<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Tímy',
  'LBL_TEAMS' => 'Tímy',
  'LBL_TEAM_ID' => 'ID tímu',
  'LBL_ASSIGNED_TO_ID' => 'Priradené používateľské ID',
  'LBL_ASSIGNED_TO_NAME' => 'Priradené k',
  'LBL_TAGS_LINK' => 'Tagy',
  'LBL_TAGS' => 'Tagy',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Dátum vytvorenia',
  'LBL_DATE_MODIFIED' => 'Dátum úpravy',
  'LBL_MODIFIED' => 'Zmenené používateľom',
  'LBL_MODIFIED_ID' => 'Upravené používateľom s ID',
  'LBL_MODIFIED_NAME' => 'Upravené používateľom s menom',
  'LBL_CREATED' => 'Vytvoril',
  'LBL_CREATED_ID' => 'Vytvorené používateľom s ID',
  'LBL_DOC_OWNER' => 'Vlastník dokumentu',
  'LBL_USER_FAVORITES' => 'Obľúbení používatelia',
  'LBL_DESCRIPTION' => 'Popis',
  'LBL_DELETED' => 'Vymazaný',
  'LBL_NAME' => 'Názov',
  'LBL_CREATED_USER' => 'Vytvorené používateľom',
  'LBL_MODIFIED_USER' => 'Zmenené používateľom',
  'LBL_LIST_NAME' => 'Názov',
  'LBL_EDIT_BUTTON' => 'Upraviť',
  'LBL_REMOVE' => 'Odstrániť',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Upravené používateľom s menom',
  'LBL_LIST_FORM_TITLE' => 'Catálogo Dependencias Zoznam',
  'LBL_MODULE_NAME' => 'Catálogo Dependencias',
  'LBL_MODULE_TITLE' => 'Catálogo Dependencias',
  'LBL_MODULE_NAME_SINGULAR' => 'Catálogo Dependencias',
  'LBL_HOMEPAGE_TITLE' => 'Moje Catálogo Dependencias',
  'LNK_NEW_RECORD' => 'Vytvoriť Catálogo Dependencias',
  'LNK_LIST' => 'Zobraziť Catálogo Dependencias',
  'LNK_IMPORT_CM_CATALOGODEPENDENCIAS' => 'Importar Catálogo Dependencias',
  'LBL_SEARCH_FORM_TITLE' => 'Vyhľadávanie Catálogo Dependencias',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Zobraziť históriu',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktivity',
  'LBL_CM_CATALOGODEPENDENCIAS_SUBPANEL_TITLE' => 'Catálogo Dependencias',
  'LBL_NEW_FORM_TITLE' => 'Nové Catálogo Dependencias',
  'LNK_IMPORT_VCARD' => 'Importar Catálogo Dependencias vCard',
  'LBL_IMPORT' => 'Importar Catálogo Dependencias',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Catálogo Dependencias record by importing a vCard from your file system.',
  'LBL_TCT_NOMBRE_DEPENDENCIA_TXF_C' => 'Nombre dependencia',
  'LBL_TCT_ESTADO_TXF_C' => 'Estado',
  'LBL_TCT_ID_DEPENDENCIA_INT_C' => 'Id Dependencia',
  'LBL_TCT_DOCS_DEPENDENCIA_TXA_C' => 'Documentos',
  'LBL_TCT_PRODUCTO_TXF_C' => 'Producto',
  'LBL_TCT_ESTATUS_DEPENDENCIA_TXF_C' => 'Estatus dependencia',
  'LBL_TCT_FORMATO_TXF_C' => 'Formato',
  'LBL_TCT_RECA_TXF_C' => 'RECA',
  'LBL_TCT_DOCS_COMISIONES_TXA_C' => 'Comisiones',
  'LBL_TCT_NOMBRE_COM_PRODUCT_TXF_C' => 'Nombre comercial producto',
  'LBL_TCT_PIE_PAGINA_TXF_C' => 'Pie de página',
  'LBL_TCT_DOCS_COMISIONES_CONTRATO_T' => 'Comisiones contrato',
  'LBL_TCT_ID_DEPENDENCIA_TXF_C' => 'Id Dependencia',
);