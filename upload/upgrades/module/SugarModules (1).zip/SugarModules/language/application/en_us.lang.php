<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['CM_LayoutOriginal'] = 'Layout Original';
$app_list_strings['moduleList']['CM_Creditos'] = 'Créditos';
$app_list_strings['moduleList']['CM_CatalogoDependencias'] = 'Catálogo Dependencias';
$app_list_strings['moduleListSingular']['CM_LayoutOriginal'] = 'Layout Original';
$app_list_strings['moduleListSingular']['CM_Creditos'] = 'Créditos';
$app_list_strings['moduleListSingular']['CM_CatalogoDependencias'] = 'Catálogo Dependencias';
$app_list_strings['cat_estatus_dependencia_list']['Activo'] = 'Activo';
$app_list_strings['cat_estatus_dependencia_list']['Inactivo'] = 'Inactivo';
$app_list_strings['cat_estatus_dependencia_list'][''] = '';
