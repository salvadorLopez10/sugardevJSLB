<?php
// created: 2018-05-29 18:40:42
$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CM_CatalogoDependencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CAT_CATALOGO_DOCUMENTOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);