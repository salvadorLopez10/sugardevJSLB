<?php
// created: 2018-05-29 18:40:39
$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);

$viewdefs['CM_Creditos']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_opportunities',
  ),
);