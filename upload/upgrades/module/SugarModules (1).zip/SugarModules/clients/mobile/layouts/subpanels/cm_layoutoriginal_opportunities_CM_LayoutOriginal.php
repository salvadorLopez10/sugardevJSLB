<?php
// created: 2018-05-29 18:40:36
$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);

$viewdefs['CM_LayoutOriginal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_opportunities',
  ),
);