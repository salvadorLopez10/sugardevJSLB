<?php
// created: 2018-05-29 18:40:35
$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_CM_CREDITOS_FROM_CM_CREDITOS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_cm_creditos',
  ),
);