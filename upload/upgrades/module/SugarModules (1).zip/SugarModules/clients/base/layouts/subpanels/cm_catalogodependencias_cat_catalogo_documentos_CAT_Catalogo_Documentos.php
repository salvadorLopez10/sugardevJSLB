<?php
// created: 2018-05-29 18:40:41
$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);

$viewdefs['CAT_Catalogo_Documentos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CATALOGODEPENDENCIAS_CAT_CATALOGO_DOCUMENTOS_FROM_CM_CATALOGODEPENDENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'cm_catalogodependencias_cat_catalogo_documentos',
  ),
);