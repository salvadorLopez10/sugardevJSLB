<?php
// created: 2018-05-29 18:40:35
$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);

$viewdefs['CM_LayoutOriginal']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_LAYOUTORIGINAL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'cm_layoutoriginal_accounts',
  ),
);