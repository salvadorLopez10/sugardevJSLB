<?php
// created: 2018-05-29 18:40:38
$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);

$viewdefs['CM_Creditos']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CM_CREDITOS_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'cm_creditos_calls',
  ),
);